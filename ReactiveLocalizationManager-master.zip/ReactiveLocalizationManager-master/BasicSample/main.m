//
//  main.m
//  ReactiveLocalizationManager
//
//  Created by Timur Kuchkarov on 26.02.15.
//  Copyright (c) 2015 i-2K. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
	}
}
