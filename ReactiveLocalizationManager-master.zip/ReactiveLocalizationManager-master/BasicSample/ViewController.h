//
//  ViewController.h
//  ReactiveLocalizationManager
//
//  Created by Timur Kuchkarov on 26.02.15.
//  Copyright (c) 2015 i-2K. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
