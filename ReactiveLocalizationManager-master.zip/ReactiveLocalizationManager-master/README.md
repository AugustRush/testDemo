# ReactiveLocalizationManager
This class helps change app language without changing device language or restarting app. 
**NOTE** This class depends on **ReactiveCocoa** (currently v.2.4.x).

# Installation

ReactiveLocalizationManager is available via [CocoaPods](http://cocoapods.org/). Add the following line to your podfile:

      pod 'ReactiveLocalizationManager', '~> 1.1'
      
Alternatively just drag&drop ReactiveLocalizationManager folder to your project.
