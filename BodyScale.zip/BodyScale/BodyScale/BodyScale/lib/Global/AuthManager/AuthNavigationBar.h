//
//  AuthNavigationBar.h
//  FFLtd
//
//  Created by 两元鱼 on 12-4-13.
//  Copyright (c) 2012年 FFLtd. All rights reserved.
//


@interface AuthNavigationBar : UINavigationBar

@end
