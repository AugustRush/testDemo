//
//  AuthManagerNavViewController.h
//  
//
//  Created by 两元鱼 on 11-6-23.
//  Copyright 2011 FFLtd. All rights reserved.
//


@interface AuthManagerNavViewController : UINavigationController

@end
