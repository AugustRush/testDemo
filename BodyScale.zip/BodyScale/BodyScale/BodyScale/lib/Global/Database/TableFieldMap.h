//
//  TableFieldMap.h
//  DZB
//
//  Created by 两元鱼 on 12-10-16.
//  Copyright (c) 2012年 FFLtd. All rights reserved.
//

#pragma mark -

#define TableName(tablename) [NSString stringWithFormat:@"%@",tablename]


#define kUserInfoList_Table                  @"USERINFOLIST_TABLE"


#pragma mark - UserInfo_Table
#define kUserInfoType                        @"userInfo_t_1"
#define kUserInfoSuperId                     @"userInfo_t_2"
#define kUserInfoId                          @"userInfo_t_3"
#define kUserInfoNickName                    @"userInfo_t_4"
#define kUserInfoSex                         @"userInfo_t_5"
#define kUserInfoPhone                       @"userInfo_t_6"
#define kUserInfoEmail                       @"userInfo_t_7"
#define kUserInfoRealName                    @"userInfo_t_8"
#define kUserInfoHeader                      @"userInfo_t_9"
#define kUserInfoAge                         @"userInfo_t_10"
#define kUserInfoHeight                      @"userInfo_t_11"
#define kUserInfoLastTime                    @"userInfo_t_12"
#define kUserInfoDefault13                   @"userInfo_t_13"
#define kUserInfoDefault14                   @"userInfo_t_14"
#define kUserInfoDefault15                   @"userInfo_t_15"
#define kUserInfoDefault16                   @"userInfo_t_16"
#define kUserInfoDefault17                   @"userInfo_t_17"
#define kUserInfoDefault18                   @"userInfo_t_18"
#define kUserInfoDefault19                   @"userInfo_t_19"
#define kUserInfoDefault20                   @"userInfo_t_20"
#define kUserInfoDefault21                   @"userInfo_t_21"
