//
//  WebUrlConstant.h
//  FFLtd
//
//  Created by lyywhg on 12-7-28.
//  Copyright (c) 2012年 BH. All rights reserved.
//

//  主要是定义 Web Url地方 （自己的）


#pragma mark -
#pragma mark 下载渠道

#define kItunesAppLink                          @"http://itunes.apple.com/cn/app/id424598114?l=en&mt=8"
#define k6RateLink                              @"itms-apps://ax.itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?type=Purple+Software&id=593652484"
#define k7RateLink                              @"itms-apps://itunes.apple.com/app/id593652484"

#define kDownloadChannelAppStore                @"app store"
#define kDownloadChannel91Helper                @"http://zs.91.com/"
#define kDownloadChannelBLHealthAppStore        @"BLHealth App Store"
#define kDownloadChannelBeijingYiXun            @"BeiJingYiXun"
#define kDownloadChannelWeiFeng                 @"WeiFeng"
#define kDownloadChannelTongBuTui               @"TongBuTui"
#define kDownloadChannelPPHelper                @"PPHelper"
#define kDownloadChannelPaoJiao                 @"PaoJiao"
#define kDownloadChannelTaiPingYang             @"TaiPingYang"
#define kDownloadChannelCanDou                  @"CanDou"
#define kDownloadChannelSoHu                    @"SoHu"


#define SXFYHospital           @"https://billionhealth.com/smart/public/hospital/introduction/sxfy.html"
#define SYDEYHospital          @"https://billionhealth.com/smart/public/hospital/introduction/sydey.html"

#define SYDEYInstruction       @"https://billionhealth.com/smart/public/hospital/sdey/guide/instructions.html"
#define SYDEYPhysicalExamination @"https://billionhealth.com/smart/public/hospital/sdey/medical_center/index.jsf?gender=1"
#define SYDEYPhysicalExamination2 @"https://billionhealth.com/smart/public/hospital/sdey/medical_center/index.jsf?gender=2"

#define PrivacyPolicyUrl       @"https://billionhealth.com/smart/qrcode/privacyPolicy.xhtml"
#define DisclaimerUrl          @"https://billionhealth.com/smart/qrcode/Disclaimer.html"
#define SBCTLAboutUsUrl        @"https://billionhealth.com/smart/qrcode/aboutus/sbctl.html"
#define SXFYAboutUsUrl         @"https://billionhealth.com/smart/qrcode/aboutus/sxfy.html"
#define SYDEYAboutUsUrl        @"https://billionhealth.com/smart/qrcode/aboutus/sydey.html"
#define SBCTLAboutUsUrl        @"https://billionhealth.com/smart/qrcode/aboutus/sbctl.html"

#define SXFYRecheckUrl         @"https://billionhealth.com/smart/qrcode/sxfyRecheck.html"

#define UserGuidanceUrl        @"https://www.billionhealth.com/smart/public/hospital/sxfy/help/index.html"


