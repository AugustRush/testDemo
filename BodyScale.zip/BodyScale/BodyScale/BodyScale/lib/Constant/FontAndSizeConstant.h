//
//  FontAndSizeConstant.h
//  MatchNet
//
//  Created by 两元鱼 on 14/6/13.
//  Copyright (c) 2014年 FFLtd. All rights reserved.
//

#define FONT8                                    [UIFont systemFontOfSize:8.0f]
#define FONT9                                    [UIFont systemFontOfSize:9.0f]
#define FONT10                                   [UIFont systemFontOfSize:10.0f]
#define FONT11                                   [UIFont systemFontOfSize:11.0f]
#define FONT12                                   [UIFont systemFontOfSize:12.0f]
#define FONT13                                   [UIFont systemFontOfSize:13.0f]
#define FONT14                                   [UIFont systemFontOfSize:14.0f]
#define FONT15                                   [UIFont systemFontOfSize:15.0f]
#define FONT16                                   [UIFont systemFontOfSize:16.0f]
#define FONT17                                   [UIFont systemFontOfSize:17.0f]
#define FONT18                                   [UIFont systemFontOfSize:18.0f]
#define FONT19                                   [UIFont systemFontOfSize:19.0f]
#define FONT20                                   [UIFont systemFontOfSize:20.0f]
#define FONT21                                   [UIFont systemFontOfSize:21.0f]
#define FONT22                                   [UIFont systemFontOfSize:22.0f]
#define FONT23                                   [UIFont systemFontOfSize:23.0f]
#define FONT30                                   [UIFont systemFontOfSize:30.0f]

#define BOLDFONT8                                    [UIFont boldSystemFontOfSize:8.0f]
#define BOLDFONT9                                    [UIFont boldSystemFontOfSize:9.0f]
#define BOLDFONT10                                   [UIFont boldSystemFontOfSize:10.0f]
#define BOLDFONT11                                   [UIFont boldSystemFontOfSize:11.0f]
#define BOLDFONT12                                   [UIFont boldSystemFontOfSize:12.0f]
#define BOLDFONT13                                   [UIFont boldSystemFontOfSize:13.0f]
#define BOLDFONT14                                   [UIFont boldSystemFontOfSize:14.0f]
#define BOLDFONT15                                   [UIFont boldSystemFontOfSize:15.0f]
#define BOLDFONT16                                   [UIFont boldSystemFontOfSize:16.0f]
#define BOLDFONT17                                   [UIFont boldSystemFontOfSize:17.0f]
#define BOLDFONT18                                   [UIFont boldSystemFontOfSize:18.0f]
#define BOLDFONT19                                   [UIFont boldSystemFontOfSize:19.0f]
#define BOLDFONT20                                   [UIFont boldSystemFontOfSize:20.0f]
#define BOLDFONT21                                   [UIFont boldSystemFontOfSize:21.0f]
#define BOLDFONT22                                   [UIFont boldSystemFontOfSize:22.0f]
#define BOLDFONT23                                   [UIFont boldSystemFontOfSize:23.0f]
#define BOLDFONT30                                   [UIFont boldSystemFontOfSize:30.0f]
