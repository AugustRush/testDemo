//
//  HttpConstant.h
//  MatchNetVersion2
//
//  Created by 两元鱼 on 10-11-28.
//  Copyright 2010 FFLtd. All rights reserved.
//

#import "ReleaseConfig.h"

#pragma mark -  NetWorkVisible Test Address
#pragma mark    网络畅通测试地址
//===============================================================================

#pragma mark -  Umeng AppKey
#pragma mark    友盟搜集健值

//===============================================================================