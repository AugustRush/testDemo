//
//  TableConstant.h
//  MatchNet
//
//  Created by 两元鱼 on 12-7-28.
//  Copyright (c) 2012年 FFLtd. All rights reserved.
//

#define kDatabaseFileName           @"FFDatabaseForBodyScale.sqlite"

#define kFilesTableName             @"FILE_TABLE"
#define kUploadFileTableName        @"UPLOAD_TABLE"
#define kDownloadFileTableName      @"DOWNLOAD_TABLE"

