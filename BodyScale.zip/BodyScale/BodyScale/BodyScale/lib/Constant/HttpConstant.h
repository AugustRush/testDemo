//
//  HttpConstant.h
//  MatchNet
//
//  Created by 两元鱼 on 10-11-28.
//  Copyright 2010 FFLtd. All rights reserved.
//


#pragma mark -
#pragma mark 环境设置
#define kBillionCall                              @""
#define kMailAddress                              @""
#define	kNetworkTestAddress                       @"http://www.baidu.com"

///////////////////////////////////////////////HTTP服务器域名配置开始//////////////////////////////////////////////////////

#define POSTURL                                   @"http://bodyscale.cookst.com/api/server.php?ac="



///////////////////////////////////////////////HTTP服务器域名配置结束//////////////////////////////////////////////////////

#define USERPHONENUMBER                           @"USERPHONENUMBER"
#define HASALREADYCONNECTED                       @"HASALREADYCONNECTED"
#define HEADERIMAGE                               @"headerimage"
