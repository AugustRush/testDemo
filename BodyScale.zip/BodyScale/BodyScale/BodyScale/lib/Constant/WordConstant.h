//
//  WordConstant.h
//  MatchNet
//com.zgntech.bodyscale
//  Created by 两元鱼 on 12-7-28.
//  Copyright (c) 2012年 FFLtd. All rights reserved.
//

#define FONT_SIZE(size)           [UIFont systemFontOfSize:size]
#define BOLD_FONT_SIZE(size)      [UIFont boldSystemFontOfSize:size]
#define UIColorRef(red1,green1,blue1) [UIColor colorWithRed:red1/255.0f green:green1/255.0f blue:blue1/255.0f alpha:1.0f]

#define TITLELABELCOLOR                          [GetWordColor colorWithHexString:@"#415560"]
#define AUTHORLABELCOLOR                         [GetWordColor colorWithHexString:@"#000000"]
#define TIMECOLOR                                [GetWordColor colorWithHexString:@"#3A3A3A"]
#define BUYCOLOR                                 [GetWordColor colorWithHexString:@"#FF6464"]
#define VIDEOSUBTITLECOLOR                       [GetWordColor colorWithHexString:@"#96B0BF"]
#define SHARECOLOR                               [GetWordColor colorWithHexString:@"#A9A7A6"]
#define LINECOLOR                                [GetWordColor colorWithHexString:@"#d3d3d1"]
#define BTNBGCOLOR                               [GetWordColor colorWithHexString:@"#d3d3d1"]

#define REDCOLOR                                 [UIColor redColor]
#define COMMONREDCOLOR                           [UIColor colorWithRed:234.0/255.0f green:72.0/255.0f blue:64.0/255.0f alpha:1.0f]

//add by Scott
#define PAGE_MARGING 15

#define BGColor UIColorRef(63, 196, 74)
