//
//  MacrosConstant.h
//  FFLtd
//
//  Created by lyywhg on 12-7-28.
//  Copyright (c) 2012年 BH. All rights reserved.
//

//  主要是定义第三方 Keys&Url等 的 头文件


#pragma mark -  Umeng AppKey
#pragma mark    友盟搜集健值
#define UMENG_APPKEY                    @"55136dd6fd98c597430007af"           // 已替换
#define Crittercism_APPKEY              @"xZHZnamE0eQqv27uYX5mCR0GvMurfDeS"

#pragma mark ShareSDK
#define ShareSDK_APPKEY @"6ac9d67cb9ac"
#define ShareSDK_SECRECT @"0bf0ce7a7c441603188f6ffca0eebf45"

#pragma mark -  Map AppKey
#pragma mark    地图组件
#define GAODE_APPKEY                    @"9f9e166a609574f55a66e404bc69cc4d"

#pragma mark -  Share Key
#pragma mark    分享组件
#define SINAWEIBOAPPKEY                 @"3772035718"                          // 已替换
#define SINAWEIBOSECRECT                @"18cc21dcf8f7e19ca0ef3f9377a94296"    // 已替换
#define SINA_REDIRECT_URI               @"http://bodyscale.cookst.com"         // 已替换

#define QQAPPID                         @"1104450944"                          // 已替换
#define QQAPPKEY                        @"dl5qOOrL0xWwQpIK"                    // 已替换
#define kQQUrl                          @"www.qq.com"

#define WECHATAPPID                     @"wx3e8f2faaef08b7fb"                  // 已替换
#define WECHATAPPKEY                    @"2eeae7d8f63320b0ba326dbda02dab7a"    // 已替换


#define RENRENAPPID                     @"272663"
#define RENRENAPIKEY                    @"9cd463687b3e491087ad71e9a733f34b"
#define RENRENSECRETKEY                 @"699cc074d7074b4c93fd705bb9980a9b"
