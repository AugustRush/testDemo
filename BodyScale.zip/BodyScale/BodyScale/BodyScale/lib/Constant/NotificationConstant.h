//
//  MessageCenter.h
//  MatchNet
//
//  Created by 两元鱼 on 13-3-18.
//  Copyright (c) 2012年 FFLtd. All rights reserved.
//
/**
 用于Notification Name的的定义，工程中的每一个Notification都必须在此定义并说明。
 */
//登录

/**
 登录完成:
 */
#define  LOGIN_OK_MESSAGE                           @"LOGIN_OK_MESSAGE"
//自动登录完成
#define  AUTOLOGIN_OK_MESSAGE                       @"AUTOLOGIN_OK_MESSAGE"

//注册完成
#define  REGISTE_OK_MESSAGE                         @"REGISTE_OK_MESSAGE"  

//登录session失效
#define  LOGIN_SESSION_FAILURE                      @"LOGIN_SESSION_FAILURE"

//登录用户与上次登录不同
#define LOGIN_USER_CHANGE_MESSAGE                   @"LOGIN_USER_CHANGE_MESSAGE"

#define  POPUP_MESSAGE                              @"POPUP_MESSAGE"

#define  POPUP_MESSAGE                              @"POPUP_MESSAGE"

//注销
#define  LOGOUT_OK_NOTIFICATION                     @"LOGOUT_OK"
//
#define  BACK_HOME                     @"BACK_HOME"

#define DID_GET_TOKEN_IN_WEB_VIEW @"didGetTokenInWebView"

#define MUSICPLAYBEGIN @"MUSICPLAYBEGIN"
#define MUSICPLAYPAUSE @"MUSICPLAYPAUSE"
#define MUSICPLAYEND   @"MUSICPLAYEND"