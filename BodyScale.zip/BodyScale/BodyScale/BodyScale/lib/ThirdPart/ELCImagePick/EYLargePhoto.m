//
//  EYLargePhoto.m
//  ELCImagePickerDemo
//
//  Created by ericyang on 14-4-24.
//  Copyright (c) 2014年 ELC Technologies. All rights reserved.
//

#import "EYLargePhoto.h"

@interface EYLargePhoto()

@end

@implementation EYLargePhoto

@end
