//
//  LineConnection.h
//  LineConnection
//
//  Created by 刘靖煌 on 14-6-20.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ShareSDK/ShareSDKPlugin.h>

///#begin zh-cn
/**
 *	@brief	Line连接器
 */
///#end
///#begin en
/**
 *	@brief	WhatsApp Connection
 */
///#end
@interface LineConnection : NSObject<ISSPlatform>

@end
