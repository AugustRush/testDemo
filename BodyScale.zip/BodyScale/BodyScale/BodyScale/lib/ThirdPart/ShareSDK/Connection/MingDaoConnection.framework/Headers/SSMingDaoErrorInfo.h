//
//  SSMingDaoErrorInfo.h
//  MingDaoConnection
//
//  Created by lisa on 14-3-6.
//  Copyright (c) 2014年 lisa. All rights reserved.
//

#import <AGCommon/CMErrorInfo.h>

///#begin zh-cn
/**
 *	@brief	明道错误信息
 */
///#end
///#begin en
/**
 *	@brief	Error information.
 */
///#end
@interface SSMingDaoErrorInfo : CMErrorInfo

@end
