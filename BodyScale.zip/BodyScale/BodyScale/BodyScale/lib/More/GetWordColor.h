//
//  GetWordColor.h
//  FFLtd
//
//  Created by lyywhg on 14-7-24.
//  Copyright (c) 2014年 FFLtd. All rights reserved.
//

@interface GetWordColor : NSObject

+(UIColor*)colorWithHexString:(NSString *)stringToConvert;
@end
