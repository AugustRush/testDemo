//
//  BaseHttpDTO.m
//  FFLtd
//
//  Created by 两元鱼 on 11-1-9.
//  Copyright 2011 FFLtd. All rights reserved.
//

#import "BaseHttpDTO.h"


@implementation BaseHttpDTO

-(void)encodeFromDictionary:(NSDictionary *)dic{
	if(dic == nil)
		return;
}

@end
