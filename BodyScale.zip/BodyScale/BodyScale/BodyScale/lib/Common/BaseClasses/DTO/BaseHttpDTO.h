//
//  BaseHttpDTO.h
//  FFLtd
//
//  Created by 两元鱼 on 11-1-9.
//  Copyright 2011 FFLtd. All rights reserved.
//


@interface BaseHttpDTO : NSObject {

}

-(void)encodeFromDictionary:(NSDictionary *)dic;

@end
