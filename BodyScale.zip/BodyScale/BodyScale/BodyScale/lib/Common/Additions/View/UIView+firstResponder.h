//
//  UIView+firstResponder.h
//  Color Calc
//
//  Created by Johnnie Walker on 25/01/2010.
//


@interface UIView (firstResponder)

- (UIView *)findFirstResponder;

@end
