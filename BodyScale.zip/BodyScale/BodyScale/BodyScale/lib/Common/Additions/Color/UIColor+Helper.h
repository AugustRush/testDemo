//
//  UIColor+Helper.h
//  FFLtd
//
//  Created by 两元鱼 on 11/6/11.
//  Copyright (c) 2011 FFLtd. All rights reserved.
//


@interface UIColor (UIColor_Helper)

+ (UIColor *)uiviewBackGroundColor;

+ (UIColor *)defaultTableBKColor;

+ (UIColor *)navTintColor;

+ (UIColor *)textlightGrayColor;
+ (UIColor *)textDarkGrayColor;


+ (UIColor *)skyBlueColor;

+ (UIColor *)darkRedColor;

+ (UIColor *)darkBlueColor;

@end
