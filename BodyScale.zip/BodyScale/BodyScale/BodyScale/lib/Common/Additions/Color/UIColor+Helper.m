//
//  UIColor+Helper.m
//  FFLtd
//
//  Created by 两元鱼 on 11/6/11.
//  Copyright (c) 2011 FFLtd. All rights reserved.
//

#import "UIColor+Helper.h"


@implementation UIColor (UIColor_Helper)

+ (UIColor *)uiviewBackGroundColor{
    UIColor *color = RGBCOLOR(240, 240, 240);
    return color;    
}

+ (UIColor*)navTintColor{
    
   // UIColor *colors = RGBCOLOR(17, 181, 229);
    UIColor *colors = RGBCOLOR(0, 143, 205);
    return colors;
}

+ (UIColor *)defaultTableBKColor{
    UIColor *color = RGBCOLOR(240, 240, 240);
    return color;
}

//add by 两元鱼

+ (UIColor *)skyBlueColor
{
    UIColor *skyBlue = RGBCOLOR(53, 79, 138);
    
    return skyBlue;
}

+ (UIColor *)darkRedColor
{
    UIColor *dardRedColor = RGBCOLOR(176, 44, 44);
    
    return dardRedColor;
}

+ (UIColor *)darkBlueColor
{
    UIColor *darkBlueColor = RGBCOLOR(30, 90, 164);
    
    return darkBlueColor;
}

+ (UIColor *)textlightGrayColor{
    
    UIColor *darkBlueColor = RGBCOLOR(165, 165, 165);
    
    return darkBlueColor;
}


+ (UIColor *)textDarkGrayColor{
    
    UIColor *color = RGBCOLOR(81, 81, 81);
    
    return color;
}



@end
