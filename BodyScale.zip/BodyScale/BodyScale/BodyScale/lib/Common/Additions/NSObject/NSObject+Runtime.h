//
//  NSObject+Runtime.h
//  FFLtd
//
//  Created by 两元鱼 on 13-4-8.
//  Copyright (c) 2013年 FFLtd. All rights reserved.
//

#import <objc/runtime.h>
@interface NSObject (Runtime)

- (NSArray *)getPropertiesNameList;
- (NSMutableDictionary *)getAllPropertyDic;

@end
