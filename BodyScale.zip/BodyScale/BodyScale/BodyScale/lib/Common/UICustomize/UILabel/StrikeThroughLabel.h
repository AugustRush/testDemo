//
//  StrikeThroughLabel.h
//  FFLtd
//
//  Created by 两元鱼 on 12-2-9.
//  Copyright (c) 2012年 FFLtd. All rights reserved.
//


@interface StrikeThroughLabel : UILabel
{
    BOOL isWithStrikeThrough_;
    
    UIImageView *line_;
}

@property (nonatomic, assign) BOOL isWithStrikeThrough;

@end
