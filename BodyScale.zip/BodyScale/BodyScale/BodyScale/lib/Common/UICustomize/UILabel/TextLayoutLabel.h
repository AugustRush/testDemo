//
//  TextLayoutLabel.h
//  Dtouching
//
//  Created by 两元鱼 on 12-5-1.
//  Copyright (c) 2012年 FFLtd. All rights reserved.
//


@interface TextLayoutLabel : UILabel

{
    
@private
    
    CGFloat characterSpacing_;       //字间距
    
    long linesSpacing_;   //行间距
    
}

@property (nonatomic, assign)CGFloat characterSpacing;

@property (nonatomic, assign)long linesSpacing;

@end
