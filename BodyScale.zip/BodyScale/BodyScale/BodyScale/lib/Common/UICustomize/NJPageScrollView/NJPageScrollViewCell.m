//
//  NJPageScrollViewCell.m
//  FFLtd
//
//  Created by 两元鱼 on 12-4-25.
//  Copyright (c) 2012年 FFLtd. All rights reserved.
//

#import "NJPageScrollViewCell.h"

@implementation NJPageScrollViewCell

@synthesize reuseIdentifier = _reuseIdentifier;

- (void)dealloc
{
}

- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super init];
    
    if (self) {
        self.reuseIdentifier = reuseIdentifier;
    }
    return self;
}

- (void)prepareForReuse
{
    
}

@end
