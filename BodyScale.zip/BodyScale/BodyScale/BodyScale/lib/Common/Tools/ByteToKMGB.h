//
//  ByteToKMGB.h
//  FFLtd
//  字节转化为kb/mb/gb
//  Created by 两元鱼 on 12-11-20.
//  Copyright (c) 2012年 FFLtd. All rights reserved.
//


@interface ByteToKMGB : NSObject

+ (NSString *)Volumn:(unsigned long long)byte;

@end
