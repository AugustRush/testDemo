//
//  TimerCal.h
//  FFLtd
//
//  Created by 两元鱼 on 13-3-29.
//  Copyright (c) 2013年 FFLtd. All rights reserved.
//

//  时间转化器


@interface TimerCal : NSObject

+ (NSString *)TimerString:(float)fTimer;

@end
