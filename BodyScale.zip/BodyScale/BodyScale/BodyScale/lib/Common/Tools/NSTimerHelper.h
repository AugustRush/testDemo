//
//  NSTimerHelper.h
//  FFLtd
//
//  Created by 两元鱼 on 12-9-4.
//  Copyright (c) 2012年 FFLtd. All rights reserved.
//


@interface NSTimerHelper : NSObject
{
    NSTimer *timer_;
}

+ (NSTimerHelper *)scheduledTimerWithTimeInterval:(NSTimeInterval)ti target:(id)aTarget selector:(SEL)aSelector userInfo:(id)userInfo repeats:(BOOL)yesOrNo;

- (void)invalidate;

@end
