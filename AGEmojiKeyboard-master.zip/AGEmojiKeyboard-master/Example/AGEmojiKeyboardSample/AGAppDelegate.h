//
//  AGAppDelegate.h
//  AGEmojiKeyboardSample
//
//  Created by Ayush on 23/03/14.
//  Copyright (c) 2014 Ayush. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
