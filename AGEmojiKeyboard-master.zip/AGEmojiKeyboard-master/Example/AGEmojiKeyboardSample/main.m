//
//  main.m
//  AGEmojiKeyboardSample
//
//  Created by Ayush on 23/03/14.
//  Copyright (c) 2014 Ayush. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AGAppDelegate.h"

int main(int argc, char * argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([AGAppDelegate class]));
  }
}
