# AGEmojiKeyboard CHANGELOG

## 0.1.0

Initial release as pod.
