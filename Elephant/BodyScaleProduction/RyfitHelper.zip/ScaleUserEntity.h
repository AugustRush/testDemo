//
//  ScaleUserEntity.h
//  BodyScale
//
//  Created by Go Salo on 14-2-19.
//  Copyright (c) 2014年 于菲. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ScaleUserEntity : NSObject

@property (nonatomic)int userId;
@property (nonatomic)int userHeight;
@property (nonatomic)int userAge;
@property (nonatomic)int userGender; // 0 女 1 男

@end
