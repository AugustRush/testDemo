//
//  ScaleRealTimeWeightEntity.h
//  BodyScale
//
//  Created by Go Salo on 14-2-20.
//  Copyright (c) 2014年 于菲. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ScaleRealTimeWeightEntity : NSObject

@property (nonatomic)int lock;
@property (nonatomic)float weight;

@end
